# HTML From Action Example - emails configured in HTML

This example shows how to configure a form endpoint.

You can test the local form with a simple local webserver:

```
cd examples/conf_in_tf
python -m http.server
```

Open [http://localhost:8000/form_index.html](http://localhost:8000/form_index.html) in your browser.



